function Invadopodia_oscillation_rewrite

% basic biological parameters

R0 = 5000;                                     
Vp = 80;                                       
V0 = 300;                                      
r = 400;                                       
Rc = 10000;                                        
A = pi*(r/2)^2/1000;                           
Ec = 0.1;                                      
kesic = 5;                                     
etaR = 10;                                     
alpha = 0.85;                                 
beta = 1.5*etaR;                               
tau1 = 300;                                   
Fs0 = 300*1;                                 
E0 = 1;                                      
E1 = 2;                                       
etas1 = 200;                                   

Rini = 0.01;
NoiseVar = 0;

% basic parameters of ions

cin0 = 1.5*10^(-4);                              
cout0 = 2;                                      
Rg = 8.314*10^(-3);                           
T = 300;                                      
PAIout0 = cout0*Rg*T;                           
Ga = -30;                                       
epsilonc = 0.1;                                  
epsilons = 10;                                   
beta_c = 45;                        
gama_c = 58;                         
foth_c = 70;                         
% beta_c = 5*10^(-5);                        
% gama_c = 8*10^(-5);                          
% foth_c = 1.1*10^(-4);                          
theta = 200000;

% for equations parameters
a = R0/Ec/A*(etaR*Vp);  
b = R0/Ec/A*(1-Vp/V0);
c = R0/Ec/A*(etaR+kesic*A/R0);
g = R0/Ec/A/V0;
e = Fs0 + alpha*etaR*Vp;
f = alpha*etaR+beta;
h = R0/Ec/A;

% physical parameters group

Fss = e;




iternum = 1;                                  
tstart = 0;
tfinal = 20000;
Ryield = zeros(iternum,1);                     
Tdetach = zeros(1, 1);                         
Ydetach = R0*ones(4, 1);                       
Tattach = zeros(1, 1);                         
Yattach = zeros(4, 1);                         
spara = [a, b, c, e, f, g, h, tau1, E0, Rc, E2p, deltay, etas1, etas2p, R0, A, Rini, NoiseVar, r,...
    cout0, Rg, T, PAIout0, Ga, epsilonc, beta_c, gama_c, foth_c, theta];
y0 = [Rini; Fss-00; cin0; 1];            
refine = 4;                                    
tout =  tstart;
yout = y0';
yplastic = 0;
teout = [];                                   
yeout = [];                                   
ieout = [];                                   
% for i=1:iternum
    tspan = [tstart, tfinal];
    [t, y] = ode45(@(t,y) Fun_elastic_ion(t,y,spara), tspan, y0);
    nt = length(t);
    tout = [tout; t(2:nt)];            
    yout = [yout; y(2:nt,:)];           
    
    



% plotting the figures
figure(1)
subplot(4,1,1)
L = plot(tout/60, (yout(:,1))/1000, 'k'), title('Length of invadopodia')
L.LineWidth = 0.75;
xlabel('Time, min' ), ylabel('R(t), {\mu}m' ) 
ax1 = gca;
ax1.FontName = 'Times New Roman';
hold on
% plot(Tdetach/60, (Ydetach(1,:))/1000, 'ro')
% hold on
subplot(4,1,2)
L = plot(tout/60, yout(:,2), 'k'), title('membrane stress')
L.LineWidth = 0.75;
xlabel('Time, min' ), ylabel('Fm, PN' )  
ax1 = gca;
ax1.FontName = 'Times New Roman';

hold on
subplot(4,1,3)
L =plot(tout/60, yout(:,3), 'k'), title('{\it C}_i_n')                            
L.LineWidth = 0.75;
xlabel('Time, min' ), ylabel('{\it C}_i_n, mmol' ) 
ax1 = gca;
ax1.FontName = 'Times New Roman';
hold on
subplot(4,1,4)
L = plot(tout/60, yout(:,4), 'k'), title('ECM')
L.LineWidth = 0.75;
xlabel('Time, min' ), ylabel('{\rho}/{\rho}_0' )  
ax1 = gca;
ax1.FontName = 'Times New Roman';

hold on
figure(3)

% subplot(2,1,1)
plot((yout(:,1))/1000, yout(:,2),'b','LineWidth',2) 
hold on
set(gca,'xminorTick','on');
xlabel('R'), ylabel('F_M' );
% Defaults for this blog post
width = 4;     % Width in inches
height = 3;    % Height in inches
alw = 0.5;    % AxesLineWidth
fsz = 14;      % Fontsize
set(gca, 'FontSize', fsz, 'LineWidth', alw); %<- Set properties
% % preserve the size of the image when save it.
set(gcf,'InvertHardcopy','on');
set(gcf,'PaperUnits', 'inches');
papersize = get(gcf, 'PaperSize');
left = (papersize(1)- width)/2;
bottom = (papersize(2)- height)/2;
myfiguresize=[left,bottom,width, height];
set(gcf,'PaperPosition', myfiguresize);
% subplot(2,1,2)
% plot((yout(:,1))/1000, yout(:,3))
% hold on

%---------------------------------------------:):)--------------------------------------------------------

end


function dydt = Fun_elastic_invadopodia(t,y,p)
[a, b, c, e, f, g, h, tau1, E0, E1, E2p, deltay, etas1, etas2, R0, A, Rini, NoiseVar] =...
           deal(p(1),p(2),p(3),p(4),p(5),p(6),p(7),p(8),p(9),p(10),p(11),p(12),...
                p(13),p(14),p(15),p(16),p(17),p(18));
dydt = zeros(4,1);
randnoise = randn(1);
dydt(1) = -(y(1)-a+y(2)*b+A*E0/R0*y(1)*h)/(c+y(2)*g);
dydt(2) = 1/tau1*(e-dydt(1)*f-y(2))+NoiseVar*randnoise/tau1; 
dydt(3) = 0;    
dydt(4) = 0;

end



function dydt = Fun_invadopodia(t, y, p, Ry)

[a, b, c, e, f, g, ~, tau1, NoiseVar] = deal(p(1),p(2),p(3),p(4),p(5),p(6),p(7),p(8),p(18));
dydt = zeros(4,1);
randnoise = randn(1);
dydt(1) = -(y(1)-a+y(2)*b)/(c+y(2)*g);          
dydt(2) =  1/tau1*(e-dydt(1)*f-y(2))+NoiseVar*randnoise/tau1;     
dydt(3) = 0;
dydt(4) = 0;
end

function dydt = Fun_single_ion(t,y,p)
[r, epsilon, cout0, Rg, T, PAIout0, Ga, epsilonc, beta_c, gama_c, foth_c]=...
           deal(p(1),p(2),p(3),p(4),p(5),p(6),p(7),p(8),p(9),p(10),p(11));
dydt = zeros(1,1);
dydt(1) = 2/r*(-beta_c*(epsilon-epsilonc)*(y(1)*Rg*T-PAIout0)+gama_c*(Rg*T*log(cout0/y(1))+Ga)-foth_c*(y(1)*Rg*T-PAIout0));
end

function dydt = Fun_elastic_ion(t,y,p)
[a, b, c, e, f, g, h, tau1, E0, Rc, E2p, deltay, etas1, etas2, R0, A, Rini, NoiseVar, r,...
    cout0, Rg, T, PAIout0, Ga, epsilonc, beta_c, gama_c, foth_c,theta]=...
           deal(p(1),p(2),p(3),p(4),p(5),p(6),p(7),p(8),p(9),p(10),p(11),p(12),...
            p(13),p(14),p(15),p(16),p(17),p(18),p(19),p(20),p(21),p(22),p(23),p(24),p(25),p(26),p(27),p(28),p(29));
dydt = zeros(4,1);
randnoise = randn(1);
dydt(1) = -(y(1)-a+y(2)*b+A*E0*y(4)/R0*y(1)*h)/(c+y(2)*g);
dydt(2) = 1/tau1*(e-dydt(1)*f-y(2)+theta*y(3))+NoiseVar*randnoise/tau1; 
dydt(3) = 3*r*(R0+y(1))/(4*Rc*Rc*Rc)*(-beta_c*(y(1)/R0-epsilonc)*(y(3)-cout0)*Rg*T+gama_c*(Rg*T*log(cout0/y(3))+Ga)-foth_c*(y(3)-cout0)*Rg*T)-y(3)*dydt(1)*3*r*r/(4*Rc*Rc*Rc);
dydt(4) = -0.00018*(y(4)-1);
end