function Invadopodia_oscillation_rewrite

% basic biological parameters

R0 = 5000;                                     
Vp = 105;                                       
V0 = 110;                                    
r = 100;                                       
Vb = 3*10^12;                                   
A = pi*r^2/1000;                          
Em = 0.1;                                     
kesim = 3*10^(-4);                            
Ec = 0.5;                                    
kesic = 1;                                     
Famax = 250;                                   
etaR = 0.5;                                   
alpha = 21.11;                                  
beta = 1400;                                      
tau1 = 250;                                   
Fs0 = 150*1;                                   
E0 = 0.6;                                       

Rini = 0.01;
NoiseVar = 0;

% basic parameters of ions

cin0 = 50;                                   
cout0 = 2000000;                              
Rg = 8.314*10^(-3);                           
T = 300;                                      
PAIout0 = cout0*Rg*T;                         
Ga = -51.5;                                    
% epsilon = (R-R0)/R0;                        
sigmac = 0;                                    
epsilons = 10;                                 
beta_c = 120;                        
J_max = 70*10^8;                         
foth_c = 10;                          
H = 800;                                       
theta = 0.2;                                 

% for equations parameters
a = A*Ec/R0+2*r*E0/1000;  
b = A*kesic/R0-etaR;
c = Famax-etaR*Vp;
g = 1-Vp/V0;
e = Fs0 + alpha*Famax - alpha*etaR*Vp;
f = alpha*etaR-beta;
h = R0/Ec/A;

% physical parameters group
Rss = a-b*e;                                   
Fss = e;
tau2 = g*e+c;                                  
const = b*f;                                   



iternum = 1;                                   
tstart = 0;
tfinal = 10000;
spara = [Ec, b, c, e, f, g, h, tau1, E0, Vb, Em, kesim, Famax, V0, R0, A, Rini, NoiseVar, r,...
    cout0, Rg, T, PAIout0, H, sigmac, beta_c, J_max, foth_c, theta];
y0 = [Rini; Fss-00; cin0; 1];             
refine = 4;                                    
tout =  tstart;
yout = y0';

% for i=1:iternum
    tspan = [tstart, tfinal];
    [t, y] = ode45(@(t,y) Fun_elastic_ion(t,y,spara), tspan, y0);
    nt = length(t);
    tout = [tout; t(2:nt)];             
    yout = [yout; y(2:nt,:)];           



% plotting the figures
figure(1)
subplot(4,1,1)
L = plot(tout/60, (yout(:,1)), 'k'), title('Length of invadopodia')
L.LineWidth = 0.75;
xlabel('Time, min' ), ylabel('R(t), {\mu}m' )  % plot length
ax1 = gca;
ax1.FontName = 'Times New Roman';
hold on
% plot(Tdetach/60, (Ydetach(1,:))/1000, 'ro')
% hold on
subplot(4,1,2)
L = plot(tout/60, yout(:,2), 'k'), title('membrane stress')      %%%-theta*yout(:,3)
L.LineWidth = 0.75;
xlabel('Time, min' ), ylabel('Fm, PN' )  % plot force
ax1 = gca;
ax1.FontName = 'Times New Roman';

hold on
subplot(4,1,3)
L =plot(tout/60, yout(:,3), 'k'), title('{\it C}_i_n')                             %plot(tout/60, yout(:,4)/1000)   % plot plastic displacement
L.LineWidth = 0.75;
xlabel('Time, min' ), ylabel('{\it C}_i_n, nmol' )  % plot force
ax1 = gca;
ax1.FontName = 'Times New Roman';
hold on
subplot(4,1,4)
L = plot(tout/60, yout(:,4), 'k'), title('ECM')
L.LineWidth = 0.75;
xlabel('Time, min' ), ylabel('{\rho}/{\rho}_0' )  % plot force
ax1 = gca;
ax1.FontName = 'Times New Roman';

hold on
figure(3)

% subplot(2,1,1)
plot((yout(:,1)), yout(:,2),'b','LineWidth',2) 
hold on
set(gca,'xminorTick','on');
xlabel('R'), ylabel('F_M' );
% Defaults for this blog post
width = 4;     % Width in inches
height = 3;    % Height in inches
alw = 0.5;    % AxesLineWidth
fsz = 14;      % Fontsize
set(gca, 'FontSize', fsz, 'LineWidth', alw); %<- Set properties
% % preserve the size of the image when save it.
set(gcf,'InvertHardcopy','on');
set(gcf,'PaperUnits', 'inches');
papersize = get(gcf, 'PaperSize');
left = (papersize(1)- width)/2;
bottom = (papersize(2)- height)/2;
myfiguresize=[left,bottom,width, height];
set(gcf,'PaperPosition', myfiguresize);
% subplot(2,1,2)


% Fmss = Fs0+alpha*etaR*Vp+theta*cin0
% taue = etaR/(A*(Ec+E0)/R0)+kesic/(A*(Ec+E0)/R0)+
% krkm = ()
end

function [value,isterminal,direction] = events1(t,y)
% Locate the time when ECM force passes through zero in a decreasing direction
% and stop integration. 
value = y(3);     % detect ECM force = 0
isterminal = 1;   % stop the integration
direction = -1;   % negative direction

end 

function [value,isterminal,direction] = events2(t,y, Ry)
% Locate the time when length pass through retraction length in a increasing direction
% and stop integration. 
value = y(1)-Ry;     % detect protrusion length get to former detach point y(1)=Ry
isterminal = 1;      % stop the integration
direction = 1;       % positive direction
end

function dydt = Fun_elastic_invadopodia(t,y,p)
[a, b, c, e, f, g, h, tau1, E0, E1, E2p, deltay, etas1, etas2, R0, A, Rini, NoiseVar] =...
           deal(p(1),p(2),p(3),p(4),p(5),p(6),p(7),p(8),p(9),p(10),p(11),p(12),...
                p(13),p(14),p(15),p(16),p(17),p(18));
dydt = zeros(4,1);
randnoise = randn(1);
dydt(1) = -(y(1)-a+y(2)*b+A*E0/R0*y(1)*h)/(c+y(2)*g);
dydt(2) = 1/tau1*(e-dydt(1)*f-y(2))+NoiseVar*randnoise/tau1; 
dydt(3) = 0;    % A*E0/R0*dydt(1)-E0/etas1*((E0+E1)/E0*y(3)-A*E1*(y(1)-Rini)/R0);
dydt(4) = 0;

end

function dydt = Fun_plasticity_invadopodia(t, y, p)
% p是参数，直接写后头就成
[a, b, c, e, f, g, h, tau1, E0, E1, E2, deltay, etas1, etas2, R0, A, Rini, NoiseVar] =...
           deal(p(1),p(2),p(3),p(4),p(5),p(6),p(7),p(8),p(9),p(10),p(11),p(12),...
                p(13),p(14),p(15),p(16),p(17),p(18));
dydt = zeros(4,1);
randnoise = randn(1);
dydt(1) = -(y(1)-a+y(2)*b+y(3)*h)/(c+y(2)*g);                  
dydt(2) =  1/tau1*(e-dydt(1)*f-y(2))+NoiseVar*randnoise/tau1;  
% plasticity
hyb_tan = (1+2/pi*atan((y(3)-deltay-A*E2*y(4)/R0)/0.00001))/2;
%hyb_tan = (1+2/pi*atan((y(3)-deltay)/0.001))/2;
dydt(3) = A*E0/R0*dydt(1)-E0/etas1*((E0+E1)/E0*y(3)-A*E1*(y(1)-y(4)-Rini)/R0)-A*E0*dydt(4)/R0;    
dydt(4) = R0/A*(y(3)-deltay-A*E2*y(4)/R0)*hyb_tan/etas2;        


end

function dydt = Fun_invadopodia(t, y, p, Ry)

[a, b, c, e, f, g, ~, tau1, NoiseVar] = deal(p(1),p(2),p(3),p(4),p(5),p(6),p(7),p(8),p(18));
dydt = zeros(4,1);
randnoise = randn(1);
dydt(1) = -(y(1)-a+y(2)*b)/(c+y(2)*g);          
dydt(2) =  1/tau1*(e-dydt(1)*f-y(2))+NoiseVar*randnoise/tau1;     
dydt(3) = 0;
dydt(4) = 0;
end

function dydt = Fun_single_ion(t,y,p)
[r, epsilon, cout0, Rg, T, PAIout0, Ga, epsilonc, beta_c, gama_c, foth_c]=...
           deal(p(1),p(2),p(3),p(4),p(5),p(6),p(7),p(8),p(9),p(10),p(11));
dydt = zeros(1,1);
dydt(1) = 2/r*(-beta_c*(epsilon-epsilonc)*(y(1)*Rg*T-PAIout0)+gama_c*(Rg*T*log(cout0/y(1))+Ga)-foth_c*(y(1)*Rg*T-PAIout0));
end

function dydt = Fun_elastic_ion(t,y,p)
[Ec, b, c, e, f, g, h, tau1, E0, Vb, Em, kesim, Famax, V0, R0, A, Rini, NoiseVar, r,...
    cout0, Rg, T, PAIout0, H, sigmac, beta_c, J_max, foth_c,theta]=...
           deal(p(1),p(2),p(3),p(4),p(5),p(6),p(7),p(8),p(9),p(10),p(11),p(12),...
            p(13),p(14),p(15),p(16),p(17),p(18),p(19),p(20),p(21),p(22),p(23),p(24),p(25),p(26),p(27),p(28),p(29));
dydt = zeros(4,1);
randnoise = randn(1);
dydt(1) = -(A*Ec/R0+2*r*E0*y(4)/1000)*y(1)/(b+y(2)/V0)+(c-y(2)*g)/(b+y(2)/V0);
dydt(2) = -1/tau1*y(2)+1/tau1*(e+f*dydt(1)+theta*y(3)); 
dydt(3) = (2*pi*r*(y(1)*1000+R0))/(pi*r*r*(y(1)*1000+R0)+Vb)*(-beta_c*(Em*(y(1)*1000/R0-0.1)+kesim*dydt(1)*1000)*(y(3)*Rg*T-PAIout0)-J_max*(y(3)*y(3)/(H*H+y(3)*y(3)))-foth_c*(y(3)*Rg*T-PAIout0));
dydt(4) = -0.0003*(y(4)-1);           
end