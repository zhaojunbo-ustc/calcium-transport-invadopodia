function single_concentration_oscillation
% basic parameters of ions
R0 = 5000;                                        
r = 100;                                       
Em = 0.1;                                      
kesic = 0.3;                                   
Rc = 10000;                                       
Vb = 3*10^12;                                     
R = 1000;                                        
% sigma = Ec*(R-R0)/R0;                          
cin0 = 50;                              
cout0 = 2000000;                                      
Rg = 8.314*10^(-3);                            
T = 300;                                       
PAIout0 = cout0*Rg*T;                            
% PAIin = cin*Rg*T;                            
% detaPAI = PAIin-PAIout;                     
H = 800;                                       
epsilon =  R/R0;                           
epsilonc = 0;                                   
epsilons = 10;                                   
% sigmac = 50;                                   
% sigmas = 600;                                 
beta_c = 120;                         
J_max = 70*10^8;                        
foth_c = 10;                         


tstart = 0;
tfinal = 4;

%%%-------------------
% relation between R& cinss
% ra_R_cinss = zeros(100,2);
% for i=1:100
%     R = 100*i;
%     epsilon = R/R0;                          
%     fun = @(vars) 3*r*(R+R0)/(4*Rc*Rc*Rc)*(-beta_c*(epsilon-epsilonc)*(vars(1)*Rg*T-PAIout0)-J_max*(vars(1)*vars(1)/(H*H+vars(1)*vars(1)))-foth_c*(vars(1)*Rg*T-PAIout0));
%     inital_guess = [1*10^(-6),1];
%     solution = fsolve(fun, inital_guess);
%     digits(4)
%     ra_R_cinss(i,1) = R/1000;
%     ra_R_cinss(i,2) = vpa(solution(1));
% end
% x = ra_R_cinss(:, 1);
% y = ra_R_cinss(:, 2);
% figure(2);
% hold on;
% plot(ra_R_cinss(:, 1), ra_R_cinss(:, 2),'k','LineWidth',2);hold on
% 
% xlabel('R, {\mu}m' ), ylabel('{\it c}_i_n_s_s, mmol/L' );
% box on;
% set(gca,'xminorTick','on');
% % Defaults for this blog post
% width = 4;     % Width in inches
% height = 3;    % Height in inches
% alw = 0.5;    % AxesLineWidth
% fsz = 14;      % Fontsize
% set(gca, 'FontSize', fsz, 'LineWidth', alw); %<- Set properties
% % % preserve the size of the image when save it.
% set(gcf,'InvertHardcopy','on');
% set(gcf,'PaperUnits', 'inches');
% papersize = get(gcf, 'PaperSize');
% left = (papersize(1)- width)/1;
% bottom = (papersize(2)- height)/1;
% myfiguresize=[left,bottom,width, height];
% set(gcf,'PaperPosition', myfiguresize);
% end

%-----------------------------------------------------------------------------------------------------
% relation between cout& cinss
% ra_cout_cinss = zeros(100,2);
% for i=1:100
%     cout = cout0+0.01*i;
%     PAIout = cout*Rg*T;                           
%     fun = @(vars) 3*r*(R+R0)/(4*Rc*Rc*Rc)*(-beta_c*(epsilon-epsilonc)*(vars(1)*Rg*T-PAIout)+gama_c*(Rg*T*log(cout/vars(1))+Ga)-foth_c*(vars(1)*Rg*T-PAIout));
%     inital_guess = [1*10^(-6),1];
%     solution = fsolve(fun, inital_guess);
%     digits(4)
%     ra_cout_cinss(i,1) = cout;
%     ra_cout_cinss(i,2) = vpa(solution(1));
% end
% x = ra_cout_cinss(:, 1);
% y = ra_cout_cinss(:, 2);
% 
% figure(2);
% hold on;
% plot(ra_cout_cinss(:, 1), ra_cout_cinss(:, 2),'k','LineWidth',2);hold on
% % title('{\it C}_o_u_t-{\it C}_i_n_s_s');
% xlabel('{\it c}_o_u_t, mmol/L' ), ylabel('{\it c}_i_n_s_s, mmol/L' )
% box on;
% set(gca,'xminorTick','on');
% % Defaults for this blog post
% width = 4;     % Width in inches
% height = 3;    % Height in inches
% alw = 0.5;    % AxesLineWidth
% fsz = 14;      % Fontsize
% set(gca, 'FontSize', fsz, 'LineWidth', alw); %<- Set properties
% % % preserve the size of the image when save it.
% set(gcf,'InvertHardcopy','on');
% set(gcf,'PaperUnits', 'inches');
% papersize = get(gcf, 'PaperSize');
% left = (papersize(1)- width)/1;
% bottom = (papersize(2)- height)/1;
% myfiguresize=[left,bottom,width, height];
% set(gcf,'PaperPosition', myfiguresize);
% end
%---------------------------------------------:)-------------------------------------------------------
% relation between beta_c& cinss
% ra_beta_cinss = zeros(100,2);
% for i=1:100
%     beta = beta_c+i*0.5;
%     fun = @(vars) 3*r*(R+R0)/(4*Rc*Rc*Rc)*(-beta*(epsilon-epsilonc)*(vars(1)*Rg*T-PAIout0)+gama_c*(Rg*T*log(cout0/vars(1))+Ga)-foth_c*(vars(1)*Rg*T-PAIout0));
%     inital_guess = [1*10^(-6),1];
%     solution = fsolve(fun, inital_guess);
%     digits(4)
%     ra_beta_cinss(i,1) = beta;
%     ra_beta_cinss(i,2) = vpa(solution(1));
% end
% x = ra_beta_cinss(:, 1);
% y = ra_beta_cinss(:, 2);
% 
% figure(2);
% hold on;
% plot(ra_beta_cinss(:, 1), ra_beta_cinss(:, 2),'k','LineWidth',2);hold on
% % title('{\beta}-{\it C}_i_n_s_s');
% xlabel('{\beta}' ), ylabel('{\it c}_i_n_s_s, mmol/L' )
% box on;
% set(gca,'xminorTick','on');
% % Defaults for this blog post
% width = 4;     % Width in inches
% height = 3;    % Height in inches
% alw = 0.5;    % AxesLineWidth
% fsz = 14;      % Fontsize
% set(gca, 'FontSize', fsz, 'LineWidth', alw); %<- Set properties
% % % preserve the size of the image when save it.
% set(gcf,'InvertHardcopy','on');
% set(gcf,'PaperUnits', 'inches');
% papersize = get(gcf, 'PaperSize');
% left = (papersize(1)- width)/1;
% bottom = (papersize(2)- height)/1;
% myfiguresize=[left,bottom,width, height];
% set(gcf,'PaperPosition', myfiguresize);
% end
%---------------------------------------------:):)--------------------------------------------------------
%relation between foth_c& cinss
% ra_foth_cinss = zeros(100,2);
% for i=1:100
%     foth = foth_c+i*0.6;
%     fun = @(vars)  3*r*(R+R0)/(4*Rc*Rc*Rc)*(-beta_c*(epsilon-epsilonc)*(vars(1)*Rg*T-PAIout0)+gama_c*(Rg*T*log(cout0/vars(1))+Ga)-foth*(vars(1)*Rg*T-PAIout0));
%     inital_guess = [1*10^(-6),1];
%     solution = fsolve(fun, inital_guess);
%     digits(4)
%     ra_foth_cinss(i,1) = foth;
%     ra_foth_cinss(i,2) = vpa(solution(1));
% end
% x = ra_foth_cinss(:, 1);
% y = ra_foth_cinss(:, 2);
% figure(2);
% hold on;
% plot(ra_foth_cinss(:, 1), ra_foth_cinss(:, 2),'k','LineWidth',2);hold on
% % title('{\it f}_o_t_h-{\it C}_i_n_s_s');
% xlabel('{\it f}_o_t_h' ), ylabel('{\it c}_i_n_s_s, mmol/L' )
% box on;
% set(gca,'xminorTick','on');
% % Defaults for this blog post
% width = 4;     % Width in inches
% height = 3;    % Height in inches
% alw = 0.5;    % AxesLineWidth
% fsz = 14;      % Fontsize
% set(gca, 'FontSize', fsz, 'LineWidth', alw); %<- Set properties
% % % preserve the size of the image when save it.
% set(gcf,'InvertHardcopy','on');
% set(gcf,'PaperUnits', 'inches');
% papersize = get(gcf, 'PaperSize');
% left = (papersize(1)- width)/1;
% bottom = (papersize(2)- height)/1;
% myfiguresize=[left,bottom,width, height];
% set(gcf,'PaperPosition', myfiguresize);
% end


%---------------------------------------------:))--------------------------------------------------------
% relation between gamma_c& cinss
% ra_gama_cinss = zeros(100,2);
% for i=1:100
%     gama = gama_c+i*0.35;
%     fun = @(vars) 3*r*(R+R0)/(4*Rc*Rc*Rc)*(-beta_c*(epsilon-epsilonc)*(vars(1)*Rg*T-PAIout0)+gama*(Rg*T*log(cout0/vars(1))+Ga)-foth_c*(vars(1)*Rg*T-PAIout0));
%     inital_guess = [1*10^(-6),1];
%     solution = fsolve(fun, inital_guess);
%     digits(4)
%     ra_gama_cinss(i,1) = gama;
%     ra_gama_cinss(i,2) = vpa(solution(1));
% end
% x = ra_gama_cinss(:, 1);
% y = ra_gama_cinss(:, 2);
% figure(2);
% hold on;
% plot(ra_gama_cinss(:, 1), ra_gama_cinss(:, 2),'k','LineWidth',2);hold on
% % title('{\gamma}-{\it C}_i_n_s_s');
% xlabel('{\gamma}'), ylabel('{\it C}_i_n_s_s, mmol/L' )
% box on;
% set(gca,'xminorTick','on');
% % Defaults for this blog post
% width = 4;     % Width in inches
% height = 3;    % Height in inches
% alw = 0.5;    % AxesLineWidth
% fsz = 14;      % Fontsize
% set(gca, 'FontSize', fsz, 'LineWidth', alw); %<- Set properties
% % % preserve the size of the image when save it.
% set(gcf,'InvertHardcopy','on');
% set(gcf,'PaperUnits', 'inches');
% papersize = get(gcf, 'PaperSize');
% left = (papersize(1)- width)/1;
% bottom = (papersize(2)- height)/1;
% myfiguresize=[left,bottom,width, height];
% set(gcf,'PaperPosition', myfiguresize);
% end
%---------------------------------------------:)----------------------------------------------------

% % heatmap beta&foth
% beta_c = 200;
% foth_c = 5;
% cinss_beta_foth = zeros(40,40);
% 
% 
% for i=1:40
%     beta = beta_c-i*4;
%     for j=1:40
%         foth = foth_c+j*1;
%         fun = @(vars) (2*pi*r*(R+R0))/(pi*r*r*(R+R0)+Vb)*(-beta*Em*(epsilon-epsilonc)*(vars(1)*Rg*T-PAIout0)-J_max*(vars(1)*vars(1)/(H*H+vars(1)*vars(1)))-foth*(vars(1)*Rg*T-PAIout0));
%         inital_guess = [1,100];
%         solution = fsolve(fun, inital_guess);
%         digits(4)
%         cinss_beta_foth(i,j) = vpa(solution(1));
%     end
% end
% figure(2);
% 
% h = heatmap(cinss_beta_foth);
% grid off;
% end
%---------------------------------------------:)--------------------------------------------------------
%heatmap gama&cout
% J_max = 90*10^8;                         
% cout0 = 500000;
% cinss_gama_cout = zeros(40,40);
% 
% 
% for i=1:40
%     Jmax = J_max-i*1*10^8;
%     for j=1:40
%         cout = cout0+j*62500;
%         fun = @(vars) (2*pi*r*(R+R0))/(pi*r*r*(R+R0)+Vb)*(-beta_c*Em*(epsilon-epsilonc)*(vars(1)*Rg*T-PAIout0)-Jmax*(vars(1)*vars(1)/(H*H+vars(1)*vars(1)))-foth_c*(vars(1)*Rg*T-cout*Rg*T));
%         inital_guess = [1,100];
%         solution = fsolve(fun, inital_guess);
%         digits(4)
%         cinss_gama_cout(i,j) = vpa(solution(1));
%     end
% end
% figure(2);
% 
% h = heatmap(cinss_gama_cout);
% grid off;
% end

% ---------------------------------------------:)-------------------------------------------------------
% 

y0 = cin0;
spara = [R0, r, Vb, R, epsilon, cout0, Rg, T, PAIout0, H, epsilonc, Em, beta_c, J_max, foth_c];
tspan = [tstart, tfinal];
[t, y] = ode45(@(t,y) Fun_single_ion(t,y,spara), tspan, y0);

nt = length(y);
cinss = y(nt,1);
 
% plot(t,charc(:),'k','lineWidth',2); hold on
plot(t, y(:),'k','LineWidth',2),title('Steady State of Calcium ion'); hold on

xlabel('Time, sec' ), ylabel('c(Ca^2^+)' )
box on;
set(gca,'xminorTick','on');
% Defaults for this blog post
width = 4;     % Width in inches
height = 3;    % Height in inches
alw = 0.5;    % AxesLineWidth
fsz = 14;      % Fontsize
set(gca, 'FontSize', fsz, 'LineWidth', alw); %<- Set properties
% preserve the size of the image when save it.
set(gcf,'InvertHardcopy','on');
set(gcf,'PaperUnits', 'inches');
papersize = get(gcf, 'PaperSize');
left = (papersize(1)- width)/1;
bottom = (papersize(2)- height)/1;
myfiguresize=[left,bottom,width, height];
set(gcf,'PaperPosition', myfiguresize);
end

% ---------------------------------------------:)------------------------------------------------------
% % %
% y0 = cin0;
% tspan = [tstart, tfinal];
% J_max = 110*10^8;                          
% beta_c = 0;
% taoo = zeros(40,40);
% for i=1:40
%     Jmax = J_max-i*2*10^8;
%     for j=1:40
%         beta = beta_c+j*3;
%         spara  = [R0, r, Vb, R, epsilon, cout0, Rg, T, PAIout0, H, epsilonc, Em, beta, Jmax, foth_c];
%         [t, y] = ode45(@(t,y) Fun_single_ion(t,y,spara), tspan, y0);
%         nt = length(y);
%         cinss = y(nt);
%         taoo(i,j) = 1/((2*pi*r*(R+R0))/(pi*r*r*(R+R0)+Vb)*abs(-beta*R/R0*Rg*T-Jmax*(2*cinss*H*H/(H*H+cinss*cinss)^2)-foth_c*Rg*T));
%     end
% end
% h = heatmap(taoo);
% 
% grid off;
% caxis([0.2 0.5])
% end
% ---------------------------------------------:)--------------------------------------------------------

% beta_c = 0;                    
% y0 = cin0;
% spara = [R0, r, Vb, R, epsilon, cout0, Rg, T, PAIout0, H, epsilonc, Em, beta_c, J_max, foth_c];
% tspan = [tstart, tfinal];
% [t, y] = ode45(@(t,y) Fun_single_ion(t,y,spara), tspan, y0);
% nt1 = length(t);
% for i=1:nt1
%     yss1(i) = (y(i)-y0)/(y(nt1)-y0);
% end
% figure(1)
% plot(t, yss1(:),'b','LineWidth',2);hold on
% 
% 
% beta_c = 120;                         
% y0 = cin0;
% spara = [R0, r, Vb, R, epsilon, cout0, Rg, T, PAIout0, H, epsilonc, Em, beta_c, J_max, foth_c];
% tspan = [tstart, tfinal];
% [t, y] = ode45(@(t,y) Fun_single_ion(t,y,spara), tspan, y0);
% nt2 = length(t);
% for i=1:nt2
%     yss2(i) = (y(i)-y0)/(y(nt2)-y0);
% end
% 
% plot(t, yss2(:),'g','LineWidth',2);hold on
% 
% 
% beta_c = 240;                         
% y0 = cin0;
% spara = [R0, r, Vb, R, epsilon, cout0, Rg, T, PAIout0, H, epsilonc, Em, beta_c, J_max, foth_c];
% tspan = [tstart, tfinal];
% [t, y] = ode45(@(t,y) Fun_single_ion(t,y,spara), tspan, y0);
% nt3 = length(t);
% for i=1:nt3
%     yss3(i) =  (y(i)-y0)/(y(nt3)-y0);
% end
% 
% plot(t, yss3(:),'k','LineWidth',2);hold on
% set(gca,'xminorTick','on');
% xlabel('Time, sec' ), ylabel('{\it c}_i_n/{\it c}_i_n_s_s' )
% hold on
% % Defaults for this blog post
% width = 4;     % Width in inches
% height = 3;    % Height in inches
% alw = 0.5;    % AxesLineWidth
% fsz = 14;      % Fontsize
% set(gca, 'FontSize', fsz, 'LineWidth', alw); %<- Set properties
% % % preserve the size of the image when save it.
% set(gcf,'InvertHardcopy','on');
% set(gcf,'PaperUnits', 'inches');
% papersize = get(gcf, 'PaperSize');
% left = (papersize(1)- width)/2;
% bottom = (papersize(2)- height)/2;
% myfiguresize=[left,bottom,width, height];
% set(gcf,'PaperPosition', myfiguresize);
% 
% legend('{\beta} = 0', '{\beta} = 120', '{\beta} = 240')
% end

%---------------------------------------------:)--------------------------------------------------------

% foth_c = 0;                          
% y0 = cin0;
% spara = [R0, r, Vb, R, epsilon, cout0, Rg, T, PAIout0, H, epsilonc, Em, beta_c, J_max, foth_c];
% tspan = [tstart, tfinal];
% [t, y] = ode45(@(t,y) Fun_single_ion(t,y,spara), tspan, y0);
% nt1 = length(t);
% for i=1:nt1
%     yss1(i) = (y(i)-y0)/(y(nt1)-y0);
% end
% 
% plot(t, yss1(:),'b','LineWidth',2);hold on
% 
% foth_c = 20;                         
% y0 = cin0;
% spara = [R0, r, Vb, R, epsilon, cout0, Rg, T, PAIout0, H, epsilonc, Em, beta_c, J_max, foth_c];
% tspan = [tstart, tfinal];
% [t, y] = ode45(@(t,y) Fun_single_ion(t,y,spara), tspan, y0);
% nt2 = length(t);
% for i=1:nt2
%     yss2(i) = (y(i)-y0)/(y(nt2)-y0);
% end
% 
% plot(t, yss2(:),'g','LineWidth',2);
% 
% hold on
% 
% foth_c = 40;                          
% y0 = cin0;
% spara = [R0, r, Vb, R, epsilon, cout0, Rg, T, PAIout0, H, epsilonc, Em, beta_c, J_max, foth_c];
% tspan = [tstart, tfinal];
% [t, y] = ode45(@(t,y) Fun_single_ion(t,y,spara), tspan, y0);
% nt3 = length(t);
% for i=1:nt3
%     yss3(i) = (y(i)-y0)/(y(nt3)-y0);
% end
% 
% plot(t, yss3(:),'k','LineWidth',2);hold on
% 
% set(gca,'xminorTick','on');
% xlabel('Time, sec' ), ylabel('{\it C}_i_n/{\it C}_i_n_s_s' )
% hold on
% % Defaults for this blog post
% width = 4;     % Width in inches
% height = 3;    % Height in inches
% alw = 0.5;    % AxesLineWidth
% fsz = 14;      % Fontsize
% set(gca, 'FontSize', fsz, 'LineWidth', alw); %<- Set properties
% % preserve the size of the image when save it.
% set(gcf,'InvertHardcopy','on');
% set(gcf,'PaperUnits', 'inches');
% papersize = get(gcf, 'PaperSize');
% left = (papersize(1)- width)/2;
% bottom = (papersize(2)- height)/2;
% myfiguresize=[left,bottom,width, height];
% set(gcf,'PaperPosition', myfiguresize);
% 
% legend('{\it f}_o_t_h = 0', '{\it f}_o_t_h = 20', '{\it f}_o_t_h = 40')
% 
% end
%---------------------------------------------:)--------------------------------------------------------

% J_max = 30*10^8;                          
% y0 = cin0;
% spara = [R0, r, Vb, R, epsilon, cout0, Rg, T, PAIout0, H, epsilonc, Em, beta_c, J_max, foth_c];
% tspan = [tstart, tfinal];
% [t, y] = ode45(@(t,y) Fun_single_ion(t,y,spara), tspan, y0);
% nt1 = length(t);
% for i=1:nt1
%     yss1(i) = (y(i)-y0)/(y(nt1)-y0);
% end
% 
% plot(t, yss1(:),'b','LineWidth',2);
% hold on
% 
% J_max = 70*10^8;                          
% y0 = cin0;
% spara = [R0, r, Vb, R, epsilon, cout0, Rg, T, PAIout0, H, epsilonc, Em, beta_c, J_max, foth_c];
% tspan = [tstart, tfinal];
% [t, y] = ode45(@(t,y) Fun_single_ion(t,y,spara), tspan, y0);
% nt2 = length(t);
% for i=1:nt2
%     yss2(i) = (y(i)-y0)/(y(nt2)-y0);
% end
% 
% plot(t, yss2(:),'g','LineWidth',2);
% hold on
% 
% J_max = 110*10^8;                          
% y0 = cin0;
% spara = [R0, r, Vb, R, epsilon, cout0, Rg, T, PAIout0, H, epsilonc, Em, beta_c, J_max, foth_c];
% tspan = [tstart, tfinal];
% [t, y] = ode45(@(t,y) Fun_single_ion(t,y,spara), tspan, y0);
% nt3 = length(t);
% for i=1:nt3
%     yss3(i) = (y(i)-y0)/(y(nt3)-y0);
% end
% 
% plot(t, yss3(:),'k','LineWidth',2);
% hold on
% set(gca,'xminorTick','on');
% xlabel('Time, sec' ), ylabel('{\it c}_i_n/{\it c}_i_n_s_s' )
% hold on
% % Defaults for this blog post
% width = 4;     % Width in inches
% height = 3;    % Height in inches
% alw = 0.5;    % AxesLineWidth
% fsz = 14;      % Fontsize
% set(gca, 'FontSize', fsz, 'LineWidth', alw); %<- Set properties
% % preserve the size of the image when save it.
% set(gcf,'InvertHardcopy','on');
% set(gcf,'PaperUnits', 'inches');
% papersize = get(gcf, 'PaperSize');
% left = (papersize(1)- width)/2;
% bottom = (papersize(2)- height)/2;
% myfiguresize=[left,bottom,width, height];
% set(gcf,'PaperPosition', myfiguresize);
% 
% legend('{\gamma} = 30', '{\gamma} = 70', '{\gamma} = 110')
% end
 
%---------------------------------------------:))--------------------------------------------------------

% cout = 1.6;                         
% y0 = cin0;
% spara = [R0, r, Vb, R, epsilon, cout, Rg, T, PAIout0, Ga, epsilonc, epsilons, beta_c, gama_c, foth_c];
% tspan = [tstart, tfinal];
% [t, y] = ode45(@(t,y) Fun_single_ion(t,y,spara), tspan, y0);
% nt1 = length(t);
% for i=1:nt1
%     yss1(i) = y(i)/y(nt1);
% end
% 
% plot(t, yss1(:),'b','LineWidth',2);
% hold on
% 
% cout = 2;                         
% y0 = cin0;
% spara = [R0, r, Vb, R, epsilon, cout, Rg, T, PAIout0, Ga, epsilonc, epsilons, beta_c, gama_c, foth_c];
% tspan = [tstart, tfinal];
% [t, y] = ode45(@(t,y) Fun_single_ion(t,y,spara), tspan, y0);
% nt2 = length(t);
% for i=1:nt2
%     yss2(i) = y(i)/y(nt2);
% end
% 
% plot(t, yss2(:),'g','LineWidth',2);
% hold on
% 
% cout = 2.4;                         
% y0 = cin0;
% spara = [R0, r, Vb, R, epsilon, cout, Rg, T, PAIout0, Ga, epsilonc, epsilons, beta_c, gama_c, foth_c];
% tspan = [tstart, tfinal];
% [t, y] = ode45(@(t,y) Fun_single_ion(t,y,spara), tspan, y0);
% nt3 = length(t);
% for i=1:nt3
%     yss3(i) = y(i)/y(nt3);
% end
% 
% plot(t, yss3(:),'k','LineWidth',2);
% hold on
% set(gca,'xminorTick','on');
% xlabel('Time, sec' ), ylabel('{\it c}_i_n/{\it c}_i_n_s_s' )
% hold on
% % Defaults for this blog post
% width = 4;     % Width in inches
% height = 3;    % Height in inches
% alw = 0.5;    % AxesLineWidth
% fsz = 14;      % Fontsize
% set(gca, 'FontSize', fsz, 'LineWidth', alw); %<- Set properties
% % preserve the size of the image when save it.
% set(gcf,'InvertHardcopy','on');
% set(gcf,'PaperUnits', 'inches');
% papersize = get(gcf, 'PaperSize');
% left = (papersize(1)- width)/2;
% bottom = (papersize(2)- height)/2;
% myfiguresize=[left,bottom,width, height];
% set(gcf,'PaperPosition', myfiguresize);
% 
% legend('cout = 1.6', 'cout = 2', 'cout = 2.4')
% end
 
%---------------------------------------------)--------------------------------------------------------
function dydt = Fun_single_ion(t,y,p)
[R0, r, Vb, R, epsilon, cout0, Rg, T, PAIout0, H, epsilonc, Em, beta_c, J_max, foth_c]=...
           deal(p(1),p(2),p(3),p(4),p(5),p(6),p(7),p(8),p(9),p(10),p(11),p(12),...
                p(13),p(14),p(15));
dydt = zeros(1,1);
dydt(1) = (2*pi*r*(R+R0))/(pi*r*r*(R+R0)+Vb)*(-beta_c*Em*(epsilon-epsilonc)*(y(1)*Rg*T-PAIout0)-J_max*(y(1)*y(1)/(H*H+y(1)*y(1)))-foth_c*(y(1)*Rg*T-PAIout0));
end